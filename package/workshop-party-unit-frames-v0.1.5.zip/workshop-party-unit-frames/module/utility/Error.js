import { MODULE_NAME } from "../settings.js";
export default class WorkshopError extends Error {
    constructor(error) {
        error = `${MODULE_NAME} | ${error}`;
        super(error);
    }
}
